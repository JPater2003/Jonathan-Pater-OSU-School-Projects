import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Alex Honigford and Jonny Pater
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /*
     * Sample test cases.
     */
    //tests for constructor
    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }

    //tests for add
    @Test
    public final void testAddEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        m.add("green");
        assertEquals(m, mExpected);
    }

    @Test
    public final void testAddOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "blue");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "blue", "green");
        m.add("green");
        assertEquals(mExpected, m);
    }

    @Test
    public final void testAddMoreThanOneTwo() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "blue",
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "blue", "green", "yellow");
        m.add("yellow");
        assertEquals(mExpected, m);
    }

    @Test
    public final void testAddMoreThanOneTen() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "blue",
                "green", "purple", "red", "orange", "pink", "white", "black",
                "magenta");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "blue", "green", "purple", "red", "orange", "pink", "white",
                "black", "magenta", "yellow");
        m.add("yellow");
        assertEquals(mExpected, m);
    }

    //tests for changeToExtractionMode
    @Test
    public final void testChangeToExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "blue",
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "blue", "green");
        m.changeToExtractionMode();
        assertEquals(mExpected, m);
    }

    //tests for removeFirst
    @Test
    public final void testRemoveFirstOne() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        String first = m.removeFirst();
        assertEquals(mExpected, m);
        assertEquals(first, "green");
    }

    @Test
    public final void testRemoveFirstTwo() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "blue",
                "green");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "green");
        String first = m.removeFirst();
        assertEquals(mExpected, m);
        assertEquals(first, "blue");
    }

    @Test
    public final void testRemoveFirstFour() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "purple", "green", "yellow", "orange");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "purple", "yellow", "orange");
        String first = m.removeFirst();
        assertEquals(mExpected, m);
        assertEquals(first, "green");
    }

    @Test
    public final void testRemoveFirstTen() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "blue",
                "green", "purple", "red", "orange", "pink", "white", "black",
                "magenta", "yellow");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "blue", "green", "purple", "red", "orange", "pink", "white",
                "magenta", "yellow");
        String first = m.removeFirst();
        assertEquals(mExpected, m);
        assertEquals(first, "black");
    }

    //tests for isInInsertionMode
    @Test
    public final void testIsInInsertionModeTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "purple", "green", "yellow", "orange");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "purple", "green", "yellow", "orange");
        boolean insert = m.isInInsertionMode();
        assertEquals(mExpected, m);
        assertEquals(true, insert);
    }

    @Test
    public final void testIsInInsertionModeFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "purple");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "purple");
        boolean insert = m.isInInsertionMode();
        assertEquals(mExpected, m);
        assertEquals(false, insert);
    }

    @Test
    public final void testIsInInsertionModeTrueWithEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        boolean insert = m.isInInsertionMode();
        assertEquals(mExpected, m);
        assertEquals(true, insert);
    }

    @Test
    public final void testIsInInsertionModeFalseWithEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        boolean insert = m.isInInsertionMode();
        assertEquals(mExpected, m);
        assertEquals(false, insert);
    }

    //test for order
    @Test
    public final void testOrderExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "purple", "green", "yellow", "orange");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "purple", "green", "yellow", "orange");
        Comparator<String> ci = m.order();
        assertEquals(mExpected, m);
        assertEquals(ORDER, ci);
    }

    @Test
    public final void testOrderInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "purple", "green", "yellow", "orange");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "purple", "green", "yellow", "orange");
        Comparator<String> ci = m.order();
        assertEquals(mExpected, m);
        assertEquals(ORDER, ci);
    }

    //tests for size
    @Test
    public final void testSizeEmptyExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false);
        int size = m.size();
        assertEquals(mExpected, m);
        assertEquals(size, 0);
    }

    @Test
    public final void testSizeOneExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "purple");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "purple");
        int size = m.size();
        assertEquals(mExpected, m);
        assertEquals(size, 1);
    }

    @Test
    public final void testSizeMoreThanOneExtractionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false,
                "purple", "green", "yellow", "orange");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "purple", "green", "yellow", "orange");
        int size = m.size();
        assertEquals(mExpected, m);
        assertEquals(size, 4);
    }

    @Test
    public final void testSizeEmptyInserstionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true);
        int size = m.size();
        assertEquals(mExpected, m);
        assertEquals(size, 0);
    }

    @Test
    public final void testSizeOneInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "purple");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "purple");
        int size = m.size();
        assertEquals(mExpected, m);
        assertEquals(size, 1);
    }

    @Test
    public final void testSizeMoreThanOneInsertionMode() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "purple", "green", "yellow", "orange");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "purple", "green", "yellow", "orange");
        int size = m.size();
        assertEquals(mExpected, m);
        assertEquals(size, 4);
    }

}
