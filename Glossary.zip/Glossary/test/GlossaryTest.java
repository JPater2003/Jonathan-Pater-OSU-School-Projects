import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class GlossaryTest {

    // Tests for termDefPair method
    //boundary case for start of sequence object
    @Test
    public void testTermDefPair1() {
        NaturalNumber pos = new NaturalNumber1L(0);
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "hello");
        seq.add(1, "world");
        seq.add(2, "");
        seq.add(3, "test line");
        NaturalNumber posExpected = new NaturalNumber1L(3);
        Sequence<String> seqExpected = new Sequence1L<>();
        seqExpected.add(0, "hello");
        seqExpected.add(1, "world");
        seqExpected.add(2, "");
        seqExpected.add(3, "test line");
        String expected = "hello world  ";
        String test = Glossary.termDefPair(seq, pos);
        assertEquals(pos, posExpected);
        assertEquals(seq, seqExpected);
        assertEquals(test, expected);
    }

    @Test
    public void testTermDefPair2() { //boundary case for end of sequence object
        NaturalNumber pos = new NaturalNumber1L(3);
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "hello");
        seq.add(1, "world");
        seq.add(2, "");
        seq.add(3, "test line");
        NaturalNumber posExpected = new NaturalNumber1L(4);
        Sequence<String> seqExpected = new Sequence1L<>();
        seqExpected.add(0, "hello");
        seqExpected.add(1, "world");
        seqExpected.add(2, "");
        seqExpected.add(3, "test line");
        String expected = "test line ";
        String test = Glossary.termDefPair(seq, pos);
        assertEquals(pos, posExpected);
        assertEquals(seq, seqExpected);
        assertEquals(test, expected);
    }

    @Test
    public void testTermDefPair3() { //routine case
        NaturalNumber pos = new NaturalNumber1L(3);
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "hello");
        seq.add(1, "world");
        seq.add(2, "");
        seq.add(3, "jonny");
        seq.add(4, "pater");
        seq.add(5, "");
        seq.add(6, "test line");
        NaturalNumber posExpected = new NaturalNumber1L(6);
        Sequence<String> seqExpected = new Sequence1L<>();
        seqExpected.add(0, "hello");
        seqExpected.add(1, "world");
        seqExpected.add(2, "");
        seqExpected.add(3, "jonny");
        seqExpected.add(4, "pater");
        seqExpected.add(5, "");
        seqExpected.add(6, "test line");
        String expected = "jonny pater  ";
        String test = Glossary.termDefPair(seq, pos);
        assertEquals(pos, posExpected);
        assertEquals(seq, seqExpected);
        assertEquals(test, expected);
    }

    @Test
    public void testTermDefPair4() { //challenging case, set of empty string
        NaturalNumber pos = new NaturalNumber1L(0);
        Sequence<String> seq = new Sequence1L<>();
        seq.add(0, "");
        NaturalNumber posExpected = new NaturalNumber1L(1);
        Sequence<String> seqExpected = new Sequence1L<>();
        seqExpected.add(0, "");
        String expected = " ";
        String test = Glossary.termDefPair(seq, pos);
        assertEquals(pos, posExpected);
        assertEquals(seq, seqExpected);
        assertEquals(test, expected);
    }

    // tests for alphabeticalTerms method
    @Test
    public void testAlphabeticalTerms1() { //routine case
        Set<String> terms = new Set1L<>();
        terms.add("jonny");
        terms.add("ryan");
        terms.add("andy");
        terms.add("michael");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("jonny");
        termsExpected.add("ryan");
        termsExpected.add("andy");
        termsExpected.add("michael");
        String[] orderedExpected = { "andy", "jonny", "michael", "ryan" };
        String[] ordered = Glossary.alphabeticalTerms(terms);
        assertEquals(ordered, orderedExpected);
        assertEquals(terms, termsExpected);
    }

    @Test
    public void testAlphabeticalTerms2() {
        //challenging case: empty string included
        Set<String> terms = new Set1L<>();
        terms.add("jonny");
        terms.add("ryan");
        terms.add("andy");
        terms.add("");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("jonny");
        termsExpected.add("ryan");
        termsExpected.add("andy");
        termsExpected.add("");
        String[] orderedExpected = { "", "andy", "jonny", "ryan" };
        String[] ordered = Glossary.alphabeticalTerms(terms);
        assertEquals(ordered, orderedExpected);
        assertEquals(terms, termsExpected);
    }

    @Test
    public void testAlphabeticalTerms3() {
        //challenging case: space included
        Set<String> terms = new Set1L<>();
        terms.add("jonny");
        terms.add("ryan");
        terms.add("andy");
        terms.add(" ");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("jonny");
        termsExpected.add("ryan");
        termsExpected.add("andy");
        termsExpected.add(" ");
        String[] orderedExpected = { " ", "andy", "jonny", "ryan" };
        String[] ordered = Glossary.alphabeticalTerms(terms);
        assertEquals(ordered, orderedExpected);
        assertEquals(terms, termsExpected);
    }

    @Test
    public void testAlphabeticalTerms4() {
        //challenging case: special character included
        Set<String> terms = new Set1L<>();
        terms.add("jonny");
        terms.add("ryan");
        terms.add("andy");
        terms.add("*");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("jonny");
        termsExpected.add("ryan");
        termsExpected.add("andy");
        termsExpected.add("*");
        String[] orderedExpected = { "*", "andy", "jonny", "ryan" };
        String[] ordered = Glossary.alphabeticalTerms(terms);
        assertEquals(ordered, orderedExpected);
        assertEquals(terms, termsExpected);
    }

    @Test
    public void testAlphabeticalTerms5() {
        //challenging case: \t included
        Set<String> terms = new Set1L<>();
        terms.add("jonny");
        terms.add("ryan");
        terms.add("andy");
        terms.add("\t");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("jonny");
        termsExpected.add("ryan");
        termsExpected.add("andy");
        termsExpected.add("\t");
        String[] orderedExpected = { "\t", "andy", "jonny", "ryan" };
        String[] ordered = Glossary.alphabeticalTerms(terms);
        assertEquals(ordered, orderedExpected);
        assertEquals(terms, termsExpected);
    }
    // test for getTermSet method

    @Test
    public void testGetTermSet1() { // routine test case
        Sequence<String> lines = new Sequence1L<>();
        lines.add(0, "hello");
        lines.add(1, "world");
        lines.add(2, "");
        lines.add(3, "jonny");
        lines.add(4, "pater");
        lines.add(5, "");
        lines.add(6, "test line");
        Sequence<String> linesExpected = new Sequence1L<>();
        linesExpected.add(0, "hello");
        linesExpected.add(1, "world");
        linesExpected.add(2, "");
        linesExpected.add(3, "jonny");
        linesExpected.add(4, "pater");
        linesExpected.add(5, "");
        linesExpected.add(6, "test line");
        Set<String> expected = new Set1L<>();
        expected.add("hello");
        expected.add("world");
        expected.add("jonny");
        expected.add("pater");
        Set<String> terms = Glossary.getTermSet(lines);
        assertEquals(lines, linesExpected);
        assertEquals(expected, terms);
    }

    @Test
    public void testGetTermSet2() { // routine test case: no terms
        Sequence<String> lines = new Sequence1L<>();
        lines.add(0, "test line");
        Sequence<String> linesExpected = new Sequence1L<>();
        linesExpected.add(0, "test line");
        Set<String> expected = new Set1L<>();
        Set<String> terms = Glossary.getTermSet(lines);
        assertEquals(lines, linesExpected);
        assertEquals(expected, terms);
    }

    //Tests linesFromInput method
    @Test
    public void testLinesFromInput1() {
        //challenging test case: empty input file
        SimpleReader in = new SimpleReader1L("blanktest.txt");
        Sequence<String> expected = new Sequence1L<>();
        Sequence<String> test = Glossary.linesFromInput(in);
        assertEquals(expected, test);
        in.close();
    }

    @Test
    public void testLinesFromInput2() { //routine test case
        SimpleReader in = new SimpleReader1L("otherTest.txt");
        Sequence<String> expected = new Sequence1L<>();
        expected.add(0, "Jonny");
        expected.add(1, "Goes to Ohio State");
        expected.add(2, "");
        expected.add(3, "Ryan");
        expected.add(4, "Is the name of one of my friends");
        expected.add(5, "");
        Sequence<String> test = Glossary.linesFromInput(in);
        assertEquals(expected, test);
        in.close();
    }

    //Tests getDef method
    @Test
    public void testGetDef1() { //routine case: no terms in definition
        Set<String> terms = new Set1L<>();
        terms.add("test");
        terms.add("test1");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("test");
        termsExpected.add("test1");
        String expected = "These are the tests";
        String def = Glossary.getDef(terms, expected);
        assertEquals(def, expected);
        assertEquals(termsExpected, terms);
    }

    @Test
    public void testGetDef2() { //routine case: terms in definition
        Set<String> terms = new Set1L<>();
        terms.add("test");
        terms.add("test1");
        Set<String> termsExpected = new Set1L<>();
        termsExpected.add("test");
        termsExpected.add("test1");
        String tests = "This is the test and test1";
        String expected = "This is the <a href = \"test.html\">test</a> "
                + "and <a href = \\\"test1.html\\\">test1</a>";
        String def = Glossary.getDef(terms, expected);
        assertEquals(def, expected);
        assertEquals(termsExpected, terms);
    }

    //Tests termHTML method
    @Test
    public void testTermHTML1() {
        //only one test case needed. routine case to check if the html outputs
        //are the same
        String term = "book";
        String def = "a printed or written literary work  ";
        String outFolder = "lib";
        Set<String> termSet = new Set1L<>();
        termSet.add("jonny");
        Glossary.termHTML(term, def, outFolder, termSet);
        SimpleReader in1 = new SimpleReader1L("lib/book.html");
        SimpleReader in2 = new SimpleReader1L("data/book.html");
        Sequence testIn1 = Glossary.linesFromInput(in1);
        Sequence expected = Glossary.linesFromInput(in2);
        assertEquals(expected, testIn1);
    }

    //Tests generateHomepage method using only one case to make sure outputs are
    //equal...the regular program must have run on the terms.txt input file for
    //this test to be accurate (THIS IS IMPORTANT)
    @Test
    public void testGenerateHomePage() {
        SimpleWriter out = new SimpleWriter1L("lib/index.html");
        String[] terms = { "book", "definition", "glossary", "language",
                "meaning", "term", "word" };
        Glossary.generateHomepage(out, terms);
        SimpleReader in1 = new SimpleReader1L("lib/index.html");
        SimpleReader in2 = new SimpleReader1L("data/index.html");
        Sequence testIn1 = Glossary.linesFromInput(in1);
        Sequence expected = Glossary.linesFromInput(in2);
        assertEquals(expected, testIn1);
    }
}
