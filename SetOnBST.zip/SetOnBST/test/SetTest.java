import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    //ADD IN MORE TEST CASES

    //Test for constructor
    @Test
    public final void testNoArgumentConstructor() {
        Set<String> test = this.constructorTest();
        Set<String> testExpected = this.constructorRef();
        assertEquals(testExpected, test);

    }

    //Tests for add
    @Test
    public final void testAddEmptySet() {
        Set<String> test = this.createFromArgsTest();
        Set<String> testExpected = this.createFromArgsRef("jonny");
        test.add("jonny");
        assertEquals(testExpected, test);

    }

    @Test
    public final void testAddNonEmptySet() {
        Set<String> test = this.createFromArgsTest("jonny");
        Set<String> testExpected = this.createFromArgsRef("jonny", "pater");
        test.add("pater");
        assertEquals(testExpected, test);

    }

    @Test
    public final void testAddNonEmptyMoreThanOne() {
        Set<String> test = this.createFromArgsTest("jonny", "pater", "OSU");
        Set<String> testExpected = this.createFromArgsRef("jonny", "pater",
                "OSU", "Cincy");
        test.add("Cincy");
        assertEquals(testExpected, test);
    }

    //Tests for remove
    @Test
    public final void testRemoveLeavingNonEmptyOne() {
        Set<String> test = this.createFromArgsTest("jonny", "pater");
        Set<String> testExpected = this.createFromArgsRef("pater");
        String removed = test.remove("jonny");
        assertEquals(testExpected, test);
        assertEquals(removed, "jonny");

    }

    @Test
    public final void testRemoveLeavingNonEmptyMoreThanOne() {
        Set<String> test = this.createFromArgsTest("jonny", "pater", "OSU",
                "Cincy");
        Set<String> testExpected = this.createFromArgsRef("jonny", "pater",
                "Cincy");
        String removed = test.remove("OSU");
        assertEquals(testExpected, test);
        assertEquals(removed, "OSU");
    }

    @Test
    public final void testRemoveLeavingEmpty() {
        Set<String> test = this.createFromArgsTest("jonny");
        Set<String> testExpected = this.createFromArgsRef();
        test.remove("jonny");
        assertEquals(testExpected, test);
    }

    //Tests for removeAny
    @Test
    public final void testRemoveAnyLeavingNonEmptyMoreThanOne() {
        Set<String> test = this.createFromArgsTest("jonny", "pater", "OSU",
                "Cincy");
        Set<String> testExpected = this.createFromArgsRef("jonny", "pater",
                "OSU", "Cincy");
        String removed = test.removeAny();
        assertEquals(testExpected.contains(removed), true);
        testExpected.remove(removed);
        assertEquals(test, testExpected);
    }

    @Test
    public final void testRemoveAnyLeavingEmpty() {
        Set<String> test = this.createFromArgsTest("jonny");
        Set<String> testExpected = this.createFromArgsRef("jonny");
        String removed = test.removeAny();
        assertEquals(testExpected.contains(removed), true);
        testExpected.remove(removed);
        assertEquals(test, testExpected);
    }

    @Test
    public final void testRemoveAnyLeavingNonEmptyOne() {
        Set<String> test = this.createFromArgsTest("jonny", "pater");
        Set<String> testExpected = this.createFromArgsRef("jonny", "pater");
        String removed = test.removeAny();
        assertEquals(testExpected.contains(removed), true);
        testExpected.remove(removed);
        assertEquals(test, testExpected);
    }

    //Tests for contains
    @Test
    public final void testContainsTrue() {
        Set<String> test = this.createFromArgsTest("CSE", "2231", "9am");
        Set<String> testExpected = this.createFromArgsRef("CSE", "2231", "9am");
        boolean contain = test.contains("2231");
        assertEquals(true, contain);
        assertEquals(testExpected, test);
    }

    @Test
    public final void testContainsNonEmptyFalse() {
        Set<String> test = this.createFromArgsTest("CSE", "2231", "9am");
        Set<String> testExpected = this.createFromArgsRef("CSE", "2231", "9am");
        boolean contain = test.contains("jonny");
        assertEquals(false, contain);
        assertEquals(testExpected, test);
    }

    @Test
    public final void testContainsEmptyFalse() {
        Set<String> test = this.createFromArgsTest();
        Set<String> testExpected = this.createFromArgsRef();
        boolean contain = test.contains("jonny");
        assertEquals(false, contain);
        assertEquals(testExpected, test);
    }

    //Tests for size
    @Test
    public final void testSizeEmpty() {
        Set<String> test = this.createFromArgsTest();
        Set<String> testExpected = this.createFromArgsRef();
        int num = test.size();
        assertEquals(testExpected, test);
        assertEquals(0, num);
    }

    @Test
    public final void testSizeNonEmptyOne() {
        Set<String> test = this.createFromArgsTest("jonny");
        Set<String> testExpected = this.createFromArgsRef("jonny");
        int num = test.size();
        assertEquals(testExpected, test);
        assertEquals(1, num);
    }

    @Test
    public final void testSizeNonEmptyMoreThanOne() {
        Set<String> test = this.createFromArgsTest("jonny", "pater", "CSE");
        Set<String> testExpected = this.createFromArgsRef("jonny", "pater",
                "CSE");
        int num = test.size();
        assertEquals(testExpected, test);
        assertEquals(3, num);
    }
}
