import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Alex Honigford
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     * </pre>
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    // Constructors Test
    @Test
    public final void testNoArgumentConstructor() {
        Map<String, String> test = this.constructorTest();
        Map<String, String> testExpected = this.constructorRef();
        assertEquals(testExpected, test);
    }

    // Tests for add method
    @Test
    public final void testAddEmpty() {
        Map<String, String> test = this.createFromArgsTest();
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater");
        test.add("Jonny", "Pater");
        assertEquals(testExpected, test);
    }

    @Test
    public final void testAddNonEmptyOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "Cincinnati", "CSE");
        test.add("Cincinnati", "CSE");
        assertEquals(testExpected, test);
    }

    @Test
    public final void testAddNonEmptyMoreThanOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "Cincinnati", "CSE");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "Cincinnati", "CSE", "Bengals", "Football");
        test.add("Bengals", "Football");
        assertEquals(testExpected, test);
    }

    // Tests for remove method
    @Test
    public final void testRemoveLeavingEmpty() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater");
        Map<String, String> testExpected = this.createFromArgsRef();
        Map.Pair<String, String> removed = test.remove("Jonny");
        assertEquals(testExpected, test);
    }

    @Test
    public final void testRemoveLeavingNonEmptyOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "CSE", "2231");
        Map<String, String> testExpected = this.createFromArgsRef("CSE",
                "2231");
        Map.Pair<String, String> removed = test.remove("Jonny");
        assertEquals(testExpected, test);
    }

    @Test
    public final void testRemoveLeavingNonEmptyMoreThanOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "CSE", "2231", "Hello", "World");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "Hello", "World");
        Map.Pair<String, String> removed = test.remove("CSE");
        assertEquals(testExpected, test);
    }

    // Test for value method
    @Test
    public final void testValue() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "CSE", "2231");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "CSE", "2231");
        String value = test.value("Jonny");
        assertEquals("Pater", value);
        assertEquals(testExpected, test);
    }

    // Test for hasKey
    @Test
    public final void testHasKeyEmptyFalse() {
        Map<String, String> test = this.createFromArgsTest();
        Map<String, String> testExpected = this.createFromArgsRef();
        boolean hasKey = test.hasKey("Jonny");
        assertEquals(false, hasKey);
        assertEquals(testExpected, test);
    }

    @Test
    public final void testHasKeyNonEmptyFalse() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater");
        boolean hasKey = test.hasKey("CSE");
        assertEquals(false, hasKey);
        assertEquals(testExpected, test);
    }

    @Test
    public final void testHasKeyNonEmptyTrue() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater");
        boolean hasKey = test.hasKey("Jonny");
        assertEquals(true, hasKey);
        assertEquals(testExpected, test);
    }

    // Test for size
    @Test
    public final void testSizeEmpty() {
        Map<String, String> test = this.createFromArgsTest();
        Map<String, String> testExpected = this.createFromArgsRef();
        int size = test.size();
        assertEquals(0, size);
        assertEquals(testExpected, test);
    }

    @Test
    public final void testSizeNonEmptyOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater");
        int size = test.size();
        assertEquals(1, size);
        assertEquals(testExpected, test);
    }

    @Test
    public final void testSizeNonEmptyMoreThanOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "CSE", "2231", "Hello", "World");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "Hello", "World", "CSE", "2231");
        int size = test.size();
        assertEquals(3, size);
        assertEquals(testExpected, test);
    }

    // Test for removeAny
    @Test
    public final void testRemoveAnyLeavingEmpty() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater");
        Map.Pair<String, String> removed = test.removeAny();
        assertEquals(true, testExpected.hasKey(removed.key())
                && testExpected.hasValue(removed.value()));
        Map.Pair<String, String> removed2 = testExpected.remove(removed.key());
        assertEquals(testExpected, test);
    }

    @Test
    public final void testRemoveAnyLeavingNonEmptyOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "CSE", "2231");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "CSE", "2231");
        Map.Pair<String, String> removed = test.removeAny();
        assertEquals(true, testExpected.hasKey(removed.key())
                && testExpected.hasValue(removed.value()));
        Map.Pair<String, String> removed2 = testExpected.remove(removed.key());
        assertEquals(testExpected, test);
    }

    @Test
    public final void testRemoveAnyLeavingNonEmptyMoreThanOne() {
        Map<String, String> test = this.createFromArgsTest("Jonny", "Pater",
                "CSE", "2231", "OSU", "Buckeyes");
        Map<String, String> testExpected = this.createFromArgsRef("Jonny",
                "Pater", "CSE", "2231", "OSU", "Buckeyes");
        Map.Pair<String, String> removed = test.removeAny();
        assertEquals(true, testExpected.hasKey(removed.key())
                && testExpected.hasValue(removed.value()));
        Map.Pair<String, String> removed2 = testExpected.remove(removed.key());
        assertEquals(testExpected, test);
    }
}
