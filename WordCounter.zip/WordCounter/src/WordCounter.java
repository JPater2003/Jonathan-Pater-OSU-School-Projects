import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Jonathan (Jonny) Pater
 *
 */
public final class WordCounter {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private WordCounter() {
    }

    /**
     * Implements the compare method for the Comparator<String> interface.
     *
     * @author Jonathan (Jonny) Pater
     *
     */
    private static class StringLT implements Comparator<String> {
        // implement the compare method to be used by the Queue sort method
        @Override
        public int compare(String o1, String o2) {
            return o1.compareToIgnoreCase(o2);
        }

    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> charSet) {
        Set<Character> temp1 = new Set1L<>();
        for (int i = 0; i < str.length(); i++) {
            char temp = str.charAt(i);
            if (!temp1.contains(temp)) {
                //checks if a given character is already in the set
                temp1.add(temp);
            }
        }
        charSet.transferFrom(temp1);
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     ** @ensures <pre>
     * nextWordOrSeparator =
     * text[position, position + |nextWordOrSeparator|) and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *    entries(nextWordOrSeparator) intersection separators = {} and
     *      (position + |nextWordOrSeparator| = |text| or
     *        entries(text[position, position + |nextWordOrSeparator| + 1))
     *          intersection separators /= {})
     * else
     *    entries(nextWordOrSeparator) is subset of separators and
     *     (position + |nextWordOrSeparator| = |text| or
     *      entries(text[position, position + |nextWordOrSeparator| + 1))
     *       is not subset of separators)
     * </pre>
     */

    private static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        StringBuilder returned = new StringBuilder("");
        String subStr = text.substring(position);
        char firstChar = subStr.charAt(0);
        boolean contain = separators.contains(firstChar);
        //checks the first character of the substring to see
        //if its a separator or not
        int i = 0; //i is a loop counter
        if (contain) {
            while (i < subStr.length()
                    //loop adds separators together to the returned word
                    && separators.contains(subStr.charAt(i))) {
                returned.append(subStr.charAt(i));
                i++;
            }
        } else {
            while (i < subStr.length()
                    //loops adds characters together to form a word.
                    //Is terminated by a separator
                    && !separators.contains(subStr.charAt(i))) {
                returned.append(subStr.charAt(i));
                i++;
            }
        }
        return returned.toString();
    }

    /**
     * Returns a map containing all of the unique words found in a given input
     * text file along with the number of times each unique word occurs in the
     * text document.
     *
     * @param input
     *            The input SimpleReader object containing the text file to be
     *            used
     * @return A map object wordCount
     * @requires The input SimpleReader object contains a valid text file to be
     *           used and that the array words is sorted alphabetically
     * @ensures The returned map object contains keys for all unique words found
     *          in the input text file and contains values for each key
     *          representing the number of occurrences for each unique word
     */
    private static Map<String, Integer> countWords(SimpleReader input) {
        Map<String, Integer> wordCount = new Map1L<>();
        int position = 0;
        final String separatorStr = " \t, \n . - ? ! = + ( ) & @#$%^&{[}] |/ \" "
                + ": ; ><`~ 1 2 3 4 5 6 7 8 9 0";
        //All characters that are considered separators for the
        //nextWordOrSeparator method
        Set<Character> separatorSet = new Set1L<>();
        generateElements(separatorStr, separatorSet);
        while (!input.atEOS()) {
            String line = input.nextLine();
            while (position < line.length()) {
                String word = nextWordOrSeparator(line, position, separatorSet);
                position = position + word.length();
                //increases position to the starting index of the next word or separator
                char firstChar = word.charAt(0);
                if (Character.isLetter(firstChar)) {
                    //checks if the returned string is a word,
                    //indicated with a letter in the first index of the string
                    if (!wordCount.hasKey(word)) {
                        //checks if the word is a key or not before adding
                        //it to the map object
                        wordCount.add(word, 1);
                    } else {
                        int count = wordCount.value(word);
                        wordCount.replaceValue(word, count + 1);
                    }
                }
            }
            position = 0;
        }
        return wordCount;
    }

    /**
     * Generates an HMTL page containing a table of all the unique words found
     * in the input text document with each word's corresponding number of
     * occurrences in the text file.
     *
     * @param out
     *            the output stream
     * @param words
     *            the array containing all unique words found in the input text
     *            file
     * @param wordCount
     *            map object containing all unique words and their corresponding
     *            word count
     * @param inFile
     *            the input stream
     * @requires words != null, wordCount !=null, out.is.open, and in.is.open
     * @ensures a valid HTML document will be the output of the method
     *
     */
    private static void outputHTML(SimpleWriter out, Queue<String> words,
            Map<String, Integer> wordCount, String inFile) {
        out.println("<html> <head> <title>Words Counted in " + inFile
                + "</title> </head> <body> <h2>Words Counted in " + inFile
                + "</h2> <hr>");
        out.println("<table border = \"1\"> <tbody>");
        out.println("<tr> <th>Words</th> <th>Counts</th>  </tr>");
        int length = words.length();
        for (int i = 0; i < length; i++) {
            //loop to add each unique word to the table
            String newWord = words.dequeue();
            out.println("<tr> <td>" + newWord + "</td>");
            out.println("<td>" + wordCount.value(newWord) + "</td> </tr>");
        }
        out.println("</tbody> </table> </body> </html>");
    }

    /**
     * Constructs and returns a Queue containing all unique words found in the
     * input text document sorted alphabetically.
     *
     * @param words
     *            the {@code Map} containing all unique words to be placed in
     *            the Queue and sorted.
     * @return the {@code Queue} containing all unique words from the input text
     *         document sorted alphabetically
     * @requires words /= null
     * @ensures the {@code Queue} returned contains all unique words and is
     *          sorted alphabetically
     */

    private static Queue<String> generateSortedQueue(
            Map<String, Integer> words) {
        Queue<String> sortedWords = new Queue1L<>();
        for (Map.Pair<String, Integer> temp : words) {
            String word = temp.key();
            sortedWords.enqueue(word);
        }
        Comparator<String> order = new StringLT();
        sortedWords.sort(order);
        return sortedWords;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.print("Enter an input file name: ");
        String input = in.nextLine();
        SimpleReader inFile1 = new SimpleReader1L(input);
        out.print("\nEnter an output file name (with a .html at the end): ");
        String output = in.nextLine();
        SimpleWriter outFile = new SimpleWriter1L(output);
        Map<String, Integer> wordCount = countWords(inFile1);
        //get words and their number of occurrences in the document
        out.println(wordCount); // TEST
        Queue<String> sortedWords = generateSortedQueue(wordCount);
        //sorts all of the unique words alphabetically in a Queue object
        out.println(sortedWords); // TEST
        outputHTML(outFile, sortedWords, wordCount, input);
        in.close();
        out.close();
        inFile1.close();
        outFile.close();
    }

}
