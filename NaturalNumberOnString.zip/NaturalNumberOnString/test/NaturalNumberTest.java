import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Jonny Pater and Alex Honigford
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    //Test for empty constructor
    @Test
    public final void testNoArgumentConstructor() {
        NaturalNumber test = this.constructorTest();
        NaturalNumber testExpected = this.constructorRef();
        assertEquals(testExpected, test);

    }

    //Tests for int constructor
    @Test
    public final void testIntConstructor0() {
        NaturalNumber test = this.constructorTest(0);
        NaturalNumber testExpected = this.constructorRef(0);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testIntConstructor5() {
        NaturalNumber test = this.constructorTest(5);
        NaturalNumber testExpected = this.constructorRef(5);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testIntConstructor1234() {
        NaturalNumber test = this.constructorTest(1234);
        NaturalNumber testExpected = this.constructorRef(1234);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testIntConstructorMaxIntValue() {
        NaturalNumber test = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber testExpected = this.constructorRef(Integer.MAX_VALUE);
        assertEquals(testExpected, test);
    }

    //Tests for string constructor
    @Test
    public final void testStringConstructor0() {
        NaturalNumber test = this.constructorTest("0");
        NaturalNumber testExpected = this.constructorRef("0");
        assertEquals(testExpected, test);

    }

    @Test
    public final void testStringConstructor4() {
        NaturalNumber test = this.constructorTest("4");
        NaturalNumber testExpected = this.constructorRef("4");
        assertEquals(testExpected, test);

    }

    @Test
    public final void testStringConstructor14567() {
        NaturalNumber test = this.constructorTest("14567");
        NaturalNumber testExpected = this.constructorRef("14567");
        assertEquals(testExpected, test);

    }

    @Test
    public final void testStringConstructorGreaterThanIntMaxValue() {
        NaturalNumber test = this.constructorTest("21474836471234");
        NaturalNumber testExpected = this.constructorRef("21474836471234");
        assertEquals(testExpected, test);
    }

    //Tests for NN constructor
    @Test
    public final void testNaturalNumberConstructor0() {
        NaturalNumber number = this.constructorRef(0);
        NaturalNumber test = this.constructorTest(number);
        NaturalNumber testExpected = this.constructorRef(number);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testNaturalNumberConstructor5() {
        NaturalNumber number = this.constructorRef(5);
        NaturalNumber test = this.constructorTest(number);
        NaturalNumber testExpected = this.constructorRef(number);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testNaturalNumberConstructor1234() {
        NaturalNumber number = this.constructorRef(1234);
        NaturalNumber test = this.constructorTest(number);
        NaturalNumber testExpected = this.constructorRef(number);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testNaturalNumberConstructorGreaterThanIntMaxValue() {
        NaturalNumber number = this.constructorRef("21474836471234");
        NaturalNumber test = this.constructorTest(number);
        NaturalNumber testExpected = this.constructorRef(number);
        assertEquals(testExpected, test);
    }

    //Tests for multiplyBy10
    @Test
    public final void testMulitplyBy10Value0Argument6() {
        NaturalNumber test = this.constructorTest(0);
        NaturalNumber testExpected = this.constructorRef(6);
        test.multiplyBy10(6);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testMulitplyBy10Value0Argument0() {
        NaturalNumber test = this.constructorTest(0);
        NaturalNumber testExpected = this.constructorRef(0);
        test.multiplyBy10(0);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testMulitplyBy10Value123Argument0() {
        NaturalNumber test = this.constructorTest(123);
        NaturalNumber testExpected = this.constructorRef(1230);
        test.multiplyBy10(0);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testMulitplyBy10Value123Argument4() {
        NaturalNumber test = this.constructorTest(123);
        NaturalNumber testExpected = this.constructorRef(1234);
        test.multiplyBy10(4);
        assertEquals(testExpected, test);

    }

    @Test
    public final void testMulitplyBy10ValueIntMaxValueArgument4() {
        NaturalNumber test = this.constructorTest("2147483647");
        NaturalNumber testExpected = this.constructorRef("21474836474");
        test.multiplyBy10(4);
        assertEquals(testExpected, test);

    }

    //Tests for divideBy10
    @Test
    public final void testDivideBy10With0() {
        NaturalNumber test = this.constructorTest(0);
        NaturalNumber testExpected = this.constructorRef(0);
        int rem = test.divideBy10();
        assertEquals(testExpected, test);
        assertEquals(rem, 0);

    }

    @Test
    public final void testDivideBy10With1() {
        NaturalNumber test = this.constructorTest(1);
        NaturalNumber testExpected = this.constructorRef(0);
        int rem = test.divideBy10();
        assertEquals(testExpected, test);
        assertEquals(rem, 1);

    }

    @Test
    public final void testDivideBy10With1234() {
        NaturalNumber test = this.constructorTest(1234);
        NaturalNumber testExpected = this.constructorRef(123);
        int rem = test.divideBy10();
        assertEquals(testExpected, test);
        assertEquals(rem, 4);

    }

    //Tests for isZero
    @Test
    public final void testIsZeroWithZeroNoArg() {
        NaturalNumber test = this.constructorTest();
        NaturalNumber testExpected = this.constructorRef();
        boolean isZero = test.isZero();
        assertEquals(testExpected, test);
        assertEquals(isZero, true);

    }

    @Test
    public final void testIsZeroWithZeroIntArg() {
        NaturalNumber test = this.constructorTest(0);
        NaturalNumber testExpected = this.constructorRef(0);
        boolean isZero = test.isZero();
        assertEquals(testExpected, test);
        assertEquals(isZero, true);

    }

    @Test
    public final void testIsZeroWithZeroStringArg() {
        NaturalNumber test = this.constructorTest("0");
        NaturalNumber testExpected = this.constructorRef("0");
        boolean isZero = test.isZero();
        assertEquals(testExpected, test);
        assertEquals(isZero, true);

    }

    @Test
    public final void testIsZeroWithZeroNaturalNumberArg() {
        NaturalNumber zero = this.constructorRef(0);
        NaturalNumber test = this.constructorTest(zero);
        NaturalNumber testExpected = this.constructorRef(zero);
        boolean isZero = test.isZero();
        assertEquals(testExpected, test);
        assertEquals(isZero, true);

    }

    @Test
    public final void testIsZeroWith1() {
        NaturalNumber test = this.constructorTest(1);
        NaturalNumber testExpected = this.constructorRef(1);
        boolean isZero = test.isZero();
        assertEquals(testExpected, test);
        assertEquals(isZero, false);

    }

    @Test
    public final void testIsZeroWith123() {
        NaturalNumber test = this.constructorTest(123);
        NaturalNumber testExpected = this.constructorRef(123);
        boolean isZero = test.isZero();
        assertEquals(testExpected, test);
        assertEquals(isZero, false);

    }

}
